 ?\_(?)_/?

I hope you will enjoy my works, improvements and bug fixes. 

Please, let me know if you find bugs.

***Update 1.2*** 
- Rebuild mesh 
- The model divided into a two objects (Shell and Bullet).  
- Added HQ model
- Added 1 level LOD 

***Update 1.2*** 
- Rebuild all textures, now they have size 2048x2048 (you can change the size of the texture on your own)
- Improvements and bug fixes in the textures.

***Update 1.3*** 
- Rebuild material (color) (Copper, Dark-Zinc)

***Commentaries*** 
- I also kept the update 1.0, so you can compare the result of the update. 
- Do not forget to leave comments. Thx.
- If you have ideas and suggestions that I could turn into the next updatings, please voice them.

***Update 1.4***
?\_(?)_/?
- Rebuild material (color) (Copper, Dark-Zinc)

***Update 1.5*** 
- Added new model: Bullet .45
* Features
	(1) - Separated
	(2) - HQ Textures 1024x1024 (Albedo, Normal, Specular, AO)
	(3) - High-poly and Low-Poly models
	(4) - LOD
	(5) - Prefabs
	
***Update 1.6*** 
- Added new model: Bullet 9x19
* Features
	(1) - Models separated
	(2) - HQ Textures 2048x2048 (Albedo, Normal, Specular, AO)
	(3) - Low-Poly models
	(4) - Prefabs